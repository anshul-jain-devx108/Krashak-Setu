import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Ionicons } from '@expo/vector-icons';
import HomeScreen from '../screens/HomeScreen';
import VendorManagement from '../screens/VendorManagement';
import AgriStore from '../screens/AgriStore';

const Tab = createBottomTabNavigator();

export default function BottomTabs() {
  return (
    <Tab.Navigator
      key="bottom-tabs" // Use 'key' instead of 'id' if 'id' is causing issues
      initialRouteName="Home"
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName;

          if (route.name === 'Home') {
            iconName = focused ? 'home' : 'home-outline';
          } else if (route.name === 'Vendor Management') {
            iconName = focused ? 'business' : 'business-outline';
          } else if (route.name === 'AgriStore') {
            iconName = focused ? 'cart' : 'cart-outline';
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: '#71BA54',
        tabBarInactiveTintColor: '#D5C37B',
        tabBarStyle: {
          height: 60,
          paddingBottom: 5,
        },
        headerShown: false, // Hide headers for each screen
      })}
    >
      <Tab.Screen name="Home" component={HomeScreen} />
      <Tab.Screen name="Vendor Management" component={VendorManagement} />
      <Tab.Screen name="AgriStore" component={AgriStore} />
    </Tab.Navigator>
  );
}
