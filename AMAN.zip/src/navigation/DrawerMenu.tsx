// // src/navigation/DrawerMenu.tsx
// import React from 'react';
// import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
// import { useNavigation } from '@react-navigation/native';

// export default function DrawerMenu() {
//   const navigation = useNavigation();

//   return (
//     <View style={styles.container}>
//       <Text style={styles.header}>Menu</Text>
//       <TouchableOpacity style={styles.menuItem} onPress={() => navigation.navigate('Home')}>
//         <Text style={styles.menuText}>Home</Text>
//       </TouchableOpacity>
//       <TouchableOpacity style={styles.menuItem} onPress={() => navigation.navigate('Vendor Management')}>
//         <Text style={styles.menuText}>Vendor Management</Text>
//       </TouchableOpacity>
//       <TouchableOpacity style={styles.menuItem} onPress={() => navigation.navigate('AgriStore')}>
//         <Text style={styles.menuText}>AgriStore</Text>
//       </TouchableOpacity>
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     padding: 20,
//   },
//   header: {
//     fontSize: 24,
//     fontWeight: 'bold',
//     marginBottom: 20,
//   },
//   menuItem: {
//     paddingVertical: 15,
//   },
//   menuText: {
//     fontSize: 18,
//   },
// });
