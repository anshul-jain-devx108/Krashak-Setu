// import React, { useEffect, useState } from 'react';
// import { View, Text, StyleSheet, SafeAreaView, ActivityIndicator } from 'react-native';
// import AsyncStorage from '@react-native-async-storage/async-storage';
// import Slider from '../components/Slider';
// import ButtonGrid from '../components/ButtonGrid';
// import { handleAsyncError } from '../utils/errorHandler';

// const HomeScreen = () => {
//   const [farmerData, setFarmerData] = useState<any>(null);
//   const [loading, setLoading] = useState(true);

//   useEffect(() => {
//     const fetchFarmerData = async () => {
//       try {
//         const storedFarmerData = await AsyncStorage.getItem('farmerData');
//         if (storedFarmerData) {
//           setFarmerData(JSON.parse(storedFarmerData));
//         }
//       } catch (error) {
//         handleAsyncError(error, 'Failed to load farmer data');
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchFarmerData();
//   }, []);

//   if (loading) return <ActivityIndicator size="large" color="#3498db" />;

//   return (
//     <SafeAreaView style={styles.container}>
//       {farmerData ? (
//         <View style={styles.header}>
//           <Text style={styles.welcomeText}>Welcome, {farmerData.name}</Text>
//           <Text style={styles.address}>{farmerData.address}</Text>
//         </View>
//       ) : (
//         <Text style={styles.errorText}>Error loading farmer data.</Text>
//       )}
//       <Slider />
//       <ButtonGrid />
//     </SafeAreaView>
//   );
// };

// const styles = StyleSheet.create({
//   container: { flex: 1, backgroundColor: '#f5f5f5' },
//   header: { padding: 20, backgroundColor: '#3498db' },
//   welcomeText: { fontSize: 22, color: '#fff', fontWeight: 'bold' },
//   address: { fontSize: 16, color: '#fff', marginTop: 5 },
//   errorText: { fontSize: 18, color: 'red', textAlign: 'center', marginTop: 20 },
// });

// export default HomeScreen;

import React from 'react';
import { StyleSheet, ScrollView } from 'react-native';
import Header from '../components/Header';
import Slider from '../components/Slider1';
import Features from '../components/Features';

const HomeScreen = ({ features, slides, navigation }) => {
  return (
    <ScrollView style={styles.container}>
      {/* Header Section */}
      <Header
        title="Krashak Welfare"
        subtitle="Empowering Farmers, Transforming Rural India"
        onProfilePress={() => navigation.navigate("FarmerProfile")}
      />

      {/* Slider Section */}
      <Slider slides={slides} />

      {/* Features Section */}
      <Features features={features} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F5F5',
  },
});

export default HomeScreen;

