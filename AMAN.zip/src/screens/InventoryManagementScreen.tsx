import React, { useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert, FlatList, TextInput, Image } from 'react-native';
import { db } from '../../firebaseConfig';  // Import Firebase config
import { collection, getDocs, updateDoc, doc, deleteDoc } from 'firebase/firestore';
//import { useDispatch, useSelector } from 'react-redux'; // Optional, if you're using Redux for state management
//import { setProducts } from '../../redux/actions'; // Redux action to set product list (optional)

const InventoryManagementScreen = () => {
  const [products, setProductsState] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editingProduct, setEditingProduct] = useState(null);
  const [updatedProductDetails, setUpdatedProductDetails] = useState({
    name: '',
    category: '',
    price: '',
    description: '',
    stock: ''
  });

  const fetchProducts = async () => {
    try {
      const querySnapshot = await getDocs(collection(db, 'products'));
      const productList = [];
      querySnapshot.forEach((doc) => {
        productList.push({ ...doc.data(), id: doc.id });
      });
      setProductsState(productList);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching products: ", error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const handleEditProduct = (product) => {
    setEditingProduct(product);
    setUpdatedProductDetails({
      name: product.name,
      category: product.category,
      price: product.price,
      description: product.description,
      stock: product.stock
    });
  };

  const handleUpdateProduct = async () => {
    if (!updatedProductDetails.name || !updatedProductDetails.price || !updatedProductDetails.stock) {
      Alert.alert('Error', 'Please fill in all required fields.');
      return;
    }

    try {
      const productRef = doc(db, 'products', editingProduct.id);
      await updateDoc(productRef, {
        name: updatedProductDetails.name,
        category: updatedProductDetails.category,
        price: updatedProductDetails.price,
        description: updatedProductDetails.description,
        stock: updatedProductDetails.stock,
      });

      fetchProducts();
      setEditingProduct(null);
      Alert.alert('Success', 'Product updated successfully!');
    } catch (error) {
      console.error("Error updating product: ", error);
      Alert.alert('Error', 'Failed to update product.');
    }
  };

  const handleDeleteProduct = async (productId) => {
    try {
      await deleteDoc(doc(db, 'products', productId));
      fetchProducts();
      Alert.alert('Success', 'Product deleted successfully!');
    } catch (error) {
      console.error("Error deleting product: ", error);
      Alert.alert('Error', 'Failed to delete product.');
    }
  };

  return (
    <View style={styles.container}>
      {loading ? (
        <Text>Loading...</Text>
      ) : (
        <>
          {editingProduct ? (
            <View style={styles.editContainer}>
              <Text style={styles.editTitle}>Edit Product</Text>
              <TextInput
                style={styles.input}
                placeholder="Product Name"
                value={updatedProductDetails.name}
                onChangeText={(text) => setUpdatedProductDetails({ ...updatedProductDetails, name: text })}
              />
              <TextInput
                style={styles.input}
                placeholder="Category"
                value={updatedProductDetails.category}
                onChangeText={(text) => setUpdatedProductDetails({ ...updatedProductDetails, category: text })}
              />
              <TextInput
                style={styles.input}
                placeholder="Price"
                value={updatedProductDetails.price}
                keyboardType="numeric"
                onChangeText={(text) => setUpdatedProductDetails({ ...updatedProductDetails, price: text })}
              />
              <TextInput
                style={styles.input}
                placeholder="Description"
                value={updatedProductDetails.description}
                onChangeText={(text) => setUpdatedProductDetails({ ...updatedProductDetails, description: text })}
              />
              <TextInput
                style={styles.input}
                placeholder="Stock"
                value={updatedProductDetails.stock}
                keyboardType="numeric"
                onChangeText={(text) => setUpdatedProductDetails({ ...updatedProductDetails, stock: text })}
              />
              <TouchableOpacity onPress={handleUpdateProduct} style={styles.button}>
                <Text style={styles.buttonText}>Update Product</Text>
              </TouchableOpacity>
            </View>
          ) : (
            <FlatList
              data={products}
              renderItem={({ item }) => (
                <View style={styles.productCard}>
                  <Image source={{ uri: item.imageUrl }} style={styles.productImage} />
                  <Text style={styles.productName}>{item.name}</Text>
                  <Text style={styles.productDetails}>Category: {item.category}</Text>
                  <Text style={styles.productDetails}>Price: ₹{item.price}</Text>
                  <Text style={styles.productDetails}>Stock: {item.stock} kg</Text>
                  <TouchableOpacity
                    style={[styles.button, styles.editButton]}
                    onPress={() => handleEditProduct(item)}
                  >
                    <Text style={styles.buttonText}>Edit</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.button, styles.deleteButton]}
                    onPress={() => handleDeleteProduct(item.id)}
                  >
                    <Text style={styles.buttonText}>Delete</Text>
                  </TouchableOpacity>
                </View>
              )}
              keyExtractor={(item) => item.id}
            />
          )}
        </>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f8ec',
    padding: 10,
  },
  editContainer: {
    padding: 20,
    backgroundColor: '#fff',
    borderRadius: 10,
    elevation: 3,
    marginBottom: 20,
  },
  editTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    marginBottom: 10,
    padding: 10,
    fontSize: 16,
  },
  button: {
    backgroundColor: '#388e3c',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginVertical: 5,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  editButton: {
    backgroundColor: '#0288d1',
  },
  deleteButton: {
    backgroundColor: '#d32f2f',
  },
  productCard: {
    backgroundColor: '#fff',
    padding: 15,
    marginBottom: 15,
    borderRadius: 10,
    elevation: 3,
  },
  productImage: {
    width: '100%',
    height: 200,
    borderRadius: 10,
    marginBottom: 10,
  },
  productName: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  productDetails: {
    fontSize: 16,
    color: '#666',
  },
});

export default InventoryManagementScreen;
