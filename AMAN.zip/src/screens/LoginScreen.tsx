// import React, { useState } from 'react';
// import {
//   View,
//   Text,
//   TextInput,
//   TouchableOpacity,
//   StyleSheet,
//   Alert,
//   TouchableWithoutFeedback,
//   Keyboard,
//   ActivityIndicator,
// } from 'react-native';
// import { collection, getDocs, query, where } from 'firebase/firestore';
// import { db } from '../../firebaseConfig'; // Firestore configuration
// import AsyncStorage from '@react-native-async-storage/async-storage';

// export default function LoginScreen({ navigation }) {
//   const [aadharNumber, setAadharNumber] = useState('');
//   const [phoneNumber, setPhoneNumber] = useState('');
//   const [loading, setLoading] = useState(false);

//   const dismissKeyboard = () => {
//     Keyboard.dismiss();
//   };

//   const validateInputs = () => {
//     if (aadharNumber.length !== 12 || isNaN(Number(aadharNumber))) {
//       Alert.alert('Invalid Input', 'Please enter a valid 12-digit Aadhar number.');
//       return false;
//     }
//     if (phoneNumber.length !== 10 || isNaN(Number(phoneNumber))) {
//       Alert.alert('Invalid Input', 'Please enter a valid 10-digit phone number.');
//       return false;
//     }
//     return true;
//   };

//   const handleLogin = async () => {
//     if (!validateInputs()) return;

//     setLoading(true);

//     try {
//       const farmersRef = collection(db, 'farmer_data');
//       const q = query(farmersRef, where('aadhar', '==', aadharNumber), where('phone', '==', phoneNumber));
//       const querySnapshot = await getDocs(q);

//       if (!querySnapshot.empty) {
//         const farmerData = querySnapshot.docs[0].data();

//         // Save Aadhar number and farmer data to AsyncStorage
//         await AsyncStorage.setItem('aadharNumber', aadharNumber);
//         await AsyncStorage.setItem('farmerData', JSON.stringify(farmerData));

//         setLoading(false);
//         Alert.alert('Login Successful', 'Welcome to the platform!');
//         navigation.navigate('MainTabs'); // Navigate to main tabs
//       } else {
//         setLoading(false);
//         Alert.alert('Authentication Failed', 'Aadhar or phone number is not registered.');
//       }
//     } catch (error) {
//       setLoading(false);
//       console.error('Login Error:', error);
//       Alert.alert('Error', 'Unable to login. Please try again.');
//     }
//   };

//   return (
//     <TouchableWithoutFeedback onPress={dismissKeyboard}>
//       <View style={styles.container}>
//         <Text style={styles.title}>Login</Text>

//         <TextInput
//           style={styles.input}
//           placeholder="Enter your 12-digit Aadhar number"
//           keyboardType="numeric"
//           maxLength={12}
//           value={aadharNumber}
//           onChangeText={setAadharNumber}
//         />

//         <TextInput
//           style={styles.input}
//           placeholder="Enter your phone number"
//           keyboardType="phone-pad"
//           maxLength={10}
//           value={phoneNumber}
//           onChangeText={setPhoneNumber}
//         />

//         <TouchableOpacity
//           style={[styles.button, { backgroundColor: loading ? '#95a5a6' : '#27ae60' }]}
//           onPress={handleLogin}
//           disabled={loading}
//         >
//           {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Login</Text>}
//         </TouchableOpacity>
//       </View>
//     </TouchableWithoutFeedback>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     justifyContent: 'center',
//     alignItems: 'center',
//     padding: 20,
//     backgroundColor: '#f7f7f7',
//   },
//   title: {
//     fontSize: 24,
//     fontWeight: 'bold',
//     marginBottom: 20,
//     color: '#34495e',
//   },
//   input: {
//     width: '100%',
//     height: 50,
//     borderWidth: 1,
//     borderColor: '#dcdcdc',
//     borderRadius: 8,
//     paddingHorizontal: 10,
//     marginBottom: 15,
//     backgroundColor: '#ffffff',
//     fontSize: 16,
//   },
//   button: {
//     width: '100%',
//     padding: 15,
//     borderRadius: 8,
//     alignItems: 'center',
//     marginTop: 10,
//   },
//   buttonText: {
//     color: '#ffffff',
//     fontSize: 16,
//     fontWeight: 'bold',
//   },
// });



import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  TouchableWithoutFeedback,
  Keyboard,
  ActivityIndicator,
} from 'react-native';
import { collection, getDocs, query, where } from 'firebase/firestore';
import { db } from '../../firebaseConfig'; // Firestore configuration
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function LoginScreen({ navigation }) {
  const [aadharNumber, setAadharNumber] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [loading, setLoading] = useState(false);

  // Check if the user is already logged in
  useEffect(() => {
    const checkLoginStatus = async () => {
      const storedAadhar = await AsyncStorage.getItem('aadharNumber');
      if (storedAadhar) {
        navigation.replace('MainTabs'); // Redirect to main tabs if logged in
      }
    };
    checkLoginStatus();
  }, [navigation]);

  const dismissKeyboard = () => {
    Keyboard.dismiss();
  };

  const validateInputs = () => {
    if (aadharNumber.length !== 12 || isNaN(Number(aadharNumber))) {
      Alert.alert('Invalid Input', 'Please enter a valid 12-digit Aadhar number.');
      return false;
    }
    if (phoneNumber.length !== 10 || isNaN(Number(phoneNumber))) {
      Alert.alert('Invalid Input', 'Please enter a valid 10-digit phone number.');
      return false;
    }
    return true;
  };

  const handleLogin = async () => {
    if (!validateInputs()) return;

    setLoading(true);

    try {
      const farmersRef = collection(db, 'farmer_data');
      const q = query(farmersRef, where('aadhar', '==', aadharNumber), where('phone', '==', phoneNumber));
      const querySnapshot = await getDocs(q);

      if (!querySnapshot.empty) {
        const farmerData = querySnapshot.docs[0].data();

        // Save Aadhar number and farmer data to AsyncStorage
        await AsyncStorage.setItem('aadharNumber', aadharNumber);
        await AsyncStorage.setItem('farmerData', JSON.stringify(farmerData));

        setLoading(false);
        Alert.alert('Login Successful', 'Welcome to the platform!');
        navigation.replace('MainTabs'); // Redirect to main tabs
      } else {
        setLoading(false);
        Alert.alert('Authentication Failed', 'Aadhar or phone number is not registered.');
      }
    } catch (error) {
      setLoading(false);
      console.error('Login Error:', error);
      Alert.alert('Error', 'Unable to login. Please try again.');
    }
  };

  return (
    <TouchableWithoutFeedback onPress={dismissKeyboard}>
      <View style={styles.container}>
        <Text style={styles.title}>Login</Text>

        <TextInput
          style={styles.input}
          placeholder="Enter your 12-digit Aadhar number"
          keyboardType="numeric"
          maxLength={12}
          value={aadharNumber}
          onChangeText={setAadharNumber}
        />

        <TextInput
          style={styles.input}
          placeholder="Enter your phone number"
          keyboardType="phone-pad"
          maxLength={10}
          value={phoneNumber}
          onChangeText={setPhoneNumber}
        />

        <TouchableOpacity
          style={[styles.button, { backgroundColor: loading ? '#95a5a6' : '#27ae60' }]}
          onPress={handleLogin}
          disabled={loading}
        >
          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.buttonText}>Login</Text>}
        </TouchableOpacity>
      </View>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#f7f7f7',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#34495e',
  },
  input: {
    width: '100%',
    height: 50,
    borderWidth: 1,
    borderColor: '#dcdcdc',
    borderRadius: 8,
    paddingHorizontal: 10,
    marginBottom: 15,
    backgroundColor: '#ffffff',
    fontSize: 16,
  },
  button: {
    width: '100%',
    padding: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 10,
  },
  buttonText: {
    color: '#ffffff',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
