// import React, { useState, useEffect } from 'react';
// import { View, Text, Button, Alert, FlatList, ActivityIndicator } from 'react-native';
// import AsyncStorage from '@react-native-async-storage/async-storage'; // Import AsyncStorage
// import { collection, getDocs, query, where, doc, updateDoc } from 'firebase/firestore';
// import { db } from '../../firebaseConfig';  // Import Firestore configuration

// const OrderManagementScreen = () => {
//   const [orders, setOrders] = useState([]); // State to hold orders
//   const [loading, setLoading] = useState(true); // Loading state for fetching data
//   const [farmerId, setFarmerId] = useState(null); // State to hold farmerId

//   // Function to fetch farmerId from AsyncStorage
//   const fetchFarmerIdFromStorage = async () => {
//     try {
//       const storedFarmerId = await AsyncStorage.getItem('aadharNumber'); // Retrieve farmerId
//       if (storedFarmerId !== null) {
//         setFarmerId(storedFarmerId); // Set farmerId state
//         console.log('Farmer ID retrieved:', storedFarmerId); // Debug log
//       } else {
//         Alert.alert('Error', 'Farmer ID not found in storage.');
//       }
//     } catch (error) {
//       console.error('Error fetching farmerId from AsyncStorage:', error);
//       Alert.alert('Error', 'Failed to fetch farmer ID.');
//     }
//   };

//   // Function to fetch orders for the specific farmerId
//   const fetchOrders = async () => {
//     if (!farmerId) return;

//     try {
//       const ordersRef = collection(db, 'orders');
//       const querySnapshot = await getDocs(ordersRef); // Fetch all orders

//       console.log('Query snapshot size:', querySnapshot.size); // Log the size of the query result

//       const ordersData = [];
//       querySnapshot.forEach((docSnapshot) => {
//         const orderArray = docSnapshot.data().orders || []; // Get orders array from the document
//         orderArray.forEach((order) => {
//           if (order.farmerId === farmerId) { // Check if the farmerId matches
//             ordersData.push({ ...order, buyerEmail: docSnapshot.id }); // Attach the buyerEmail (doc.id)
//           }
//         });
//       });

//       console.log('Orders data fetched:', ordersData);
//       setOrders(ordersData);

//     } catch (error) {
//       console.error('Error fetching orders:', error);
//       Alert.alert('Error', 'Failed to fetch orders.');
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Handle accepting an order
//   const acceptOrder = async (orderId) => {
//     try {
//       setLoading(true);

//       // Fetch all orders in the 'orders' collection
//       const ordersRef = collection(db, 'orders');
//       const querySnapshot = await getDocs(ordersRef);

//       // Loop through all documents in the 'orders' collection
//       querySnapshot.forEach(async (docSnapshot) => {
//         const orderArray = docSnapshot.data().orders || []; // Get the orders array from the document
//         const orderIndex = orderArray.findIndex(order => order.orderId === orderId); // Find the order by orderId

//         if (orderIndex !== -1) {  // If the order with the given orderId is found
//           const orderDocRef = doc(db, 'orders', docSnapshot.id); // Get reference to the specific order document
//           const updatedOrder = orderArray[orderIndex]; // Get the specific order to update

//           // Update the farmerStatus to 'Accepted' for the found order
//           updatedOrder.farmerStatus = 'Accepted';

//           // Update the document with the modified order array
//           await updateDoc(orderDocRef, {
//             orders: [
//               ...orderArray.slice(0, orderIndex), // Orders before the updated one
//               updatedOrder, // The updated order
//               ...orderArray.slice(orderIndex + 1), // Orders after the updated one
//             ],
//           });

//           Alert.alert('Success', 'Order has been accepted.');
//           fetchOrders(); // Re-fetch the orders after accepting
//         }
//       });
//     } catch (error) {
//       console.error('Error accepting order:', error);
//       Alert.alert('Error', 'Failed to accept the order.');
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Handle denying an order
//   const denyOrder = async (orderId) => {
//     try {
//       setLoading(true);

//       // Fetch all orders in the 'orders' collection
//       const ordersRef = collection(db, 'orders');
//       const querySnapshot = await getDocs(ordersRef);

//       // Loop through all documents in the 'orders' collection
//       querySnapshot.forEach(async (docSnapshot) => {
//         const orderArray = docSnapshot.data().orders || []; // Get the orders array from the document
//         const orderIndex = orderArray.findIndex(order => order.orderId === orderId); // Find the order by orderId

//         if (orderIndex !== -1) { // If the order with the given orderId is found
//           const orderDocRef = doc(db, 'orders', docSnapshot.id); // Get reference to the specific order document
//           const updatedOrder = orderArray[orderIndex]; // Get the specific order to update

//           // Update the farmerStatus to 'Denied' for the found order
//           updatedOrder.farmerStatus = 'Denied';

//           // Update the document with the modified order array
//           await updateDoc(orderDocRef, {
//             orders: [
//               ...orderArray.slice(0, orderIndex), // Orders before the updated one
//               updatedOrder, // The updated order
//               ...orderArray.slice(orderIndex + 1), // Orders after the updated one
//             ],
//           });

//           Alert.alert('Success', 'Order has been denied.');
//           fetchOrders(); // Re-fetch the orders after denying
//         }
//       });
//     } catch (error) {
//       console.error('Error denying order:', error);
//       Alert.alert('Error', 'Failed to deny the order.');
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Fetch orders when component mounts or farmerId is updated
//   useEffect(() => {
//     fetchFarmerIdFromStorage(); // Fetch farmerId when the component mounts
//   }, []);

//   useEffect(() => {
//     if (farmerId) {
//       fetchOrders(); // Fetch orders once farmerId is available
//     }
//   }, [farmerId]);

//   // Render individual order items
//   const renderItem = ({ item }) => (
//     <View style={{ marginBottom: 10, padding: 15, borderWidth: 1 }}>
//       <Text>Order ID: {item.orderId}</Text>
//       <Text>Crop: {item.cropName}</Text>
//       <Text>Status: {item.farmerStatus || 'Pending'}</Text>
//       <Text>Quantity: {item.quantity}</Text>
//       <Text>Total Price: ₹{item.totalPrice}</Text>
//       <Text>Address: {item.address}</Text>
//       <View style={{ marginTop: 10 }}>
//         <Button title="Accept" onPress={() => acceptOrder(item.orderId)} />
//         <Button title="Deny" onPress={() => denyOrder(item.orderId)} color="red" />
//       </View>
//     </View>
//   );

//   console.log('Orders:', orders); // Debug log to check orders data

//   return (
//     <View style={{ flex: 1, padding: 20 }}>
//       {loading ? (
//         <ActivityIndicator size="large" color="#0000ff" />
//       ) : (
//         <FlatList
//           data={orders}
//           keyExtractor={(item) => item.orderId} // Use orderId as the unique key for each order
//           renderItem={renderItem}
//           ListEmptyComponent={<Text>No orders found for this farmer.</Text>} // Empty state if no orders
//         />
//       )}
//     </View>
//   );
// };

// export default OrderManagementScreen;


// import React, { useState, useEffect } from 'react';
// import { View, Text, Button, Alert, FlatList, ActivityIndicator } from 'react-native';
// import AsyncStorage from '@react-native-async-storage/async-storage'; // Import AsyncStorage
// import { collection, getDocs, query, where, doc, updateDoc } from 'firebase/firestore';
// import { db } from '../../firebaseConfig';  // Import Firestore configuration

// const OrderManagementScreen = () => {
//   const [orders, setOrders] = useState([]); // State to hold orders
//   const [loading, setLoading] = useState(true); // Loading state for fetching data
//   const [farmerId, setFarmerId] = useState(null); // State to hold farmerId

//   // Function to fetch farmerId from AsyncStorage
//   const fetchFarmerIdFromStorage = async () => {
//     try {
//       const storedFarmerId = await AsyncStorage.getItem('aadharNumber'); // Retrieve farmerId
//       if (storedFarmerId !== null) {
//         setFarmerId(storedFarmerId); // Set farmerId state
//         console.log('Farmer ID retrieved:', storedFarmerId); // Debug log
//       } else {
//         Alert.alert('Error', 'Farmer ID not found in storage.');
//       }
//     } catch (error) {
//       console.error('Error fetching farmerId from AsyncStorage:', error);
//       Alert.alert('Error', 'Failed to fetch farmer ID.');
//     }
//   };

//   // Function to fetch orders for the specific farmerId
//   const fetchOrders = async () => {
//     if (!farmerId) return;
  
//     try {
//       const ordersRef = collection(db, 'orders');
//       const querySnapshot = await getDocs(ordersRef); // Fetch all orders
  
//       console.log('Query snapshot size:', querySnapshot.size); // Log the size of the query result
  
//       const ordersData = [];
//       querySnapshot.forEach((docSnapshot) => {
//         const orderArray = docSnapshot.data().orders || []; // Correct way to access document data
//         orderArray.forEach((order) => {
//           if (order.farmerId === farmerId) { // Check if the farmerId matches
//             ordersData.push({ ...order, buyerEmail: docSnapshot.id }); // Attach the buyerEmail (doc.id)
//           }
//         });
//       });
  
//       console.log('Orders data fetched:', ordersData);
//       setOrders(ordersData);
  
//     } catch (error) {
//       console.error('Error fetching orders:', error);
//       Alert.alert('Error', 'Failed to fetch orders.');
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Handle accepting an order
//   const acceptOrder = async (orderId) => {
//     try {
//       setLoading(true);
  
//       // Fetch all orders in the 'orders' collection
//       const ordersRef = collection(db, 'orders');
//       const querySnapshot = await getDocs(ordersRef);
  
//       // Loop through all documents in the 'orders' collection
//       querySnapshot.forEach(async (docSnapshot) => {
//         const orderArray = docSnapshot.data().orders || []; // Get the orders array from the document
//         const orderIndex = orderArray.findIndex(order => order.orderId === orderId); // Find the order by orderId
  
//         if (orderIndex !== -1) {  // If the order with the given orderId is found
//           const orderDocRef = doc(db, 'orders', docSnapshot.id); // Get reference to the specific order document
//           const updatedOrder = orderArray[orderIndex]; // Get the specific order to update
  
//           // Update the farmerStatus to 'Accepted' for the found order
//           updatedOrder.farmerStatus = 'Accepted';
  
//           // Update the document with the modified order array
//           await updateDoc(orderDocRef, {
//             orders: [
//               ...orderArray.slice(0, orderIndex), // Orders before the updated one
//               updatedOrder, // The updated order
//               ...orderArray.slice(orderIndex + 1), // Orders after the updated one
//             ],
//           });
  
//           Alert.alert('Success', 'Order has been accepted.');
//           fetchOrders(); // Re-fetch the orders after accepting
//         }
//       });
//     } catch (error) {
//       console.error('Error accepting order:', error);
//       Alert.alert('Error', 'Failed to accept the order.');
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Handle denying an order
//   const denyOrder = async (orderId) => {
//     try {
//       setLoading(true);
  
//       // Fetch all orders in the 'orders' collection
//       const ordersRef = collection(db, 'orders');
//       const querySnapshot = await getDocs(ordersRef);
  
//       // Loop through all documents in the 'orders' collection
//       querySnapshot.forEach(async (docSnapshot) => {
//         const orderArray = docSnapshot.data().orders || []; // Get the orders array from the document
//         const orderIndex = orderArray.findIndex(order => order.orderId === orderId); // Find the order by orderId
  
//         if (orderIndex !== -1) { // If the order with the given orderId is found
//           const orderDocRef = doc(db, 'orders', docSnapshot.id); // Get reference to the specific order document
//           const updatedOrder = orderArray[orderIndex]; // Get the specific order to update
  
//           // Update the farmerStatus to 'Denied' for the found order
//           updatedOrder.farmerStatus = 'Denied';
  
//           // Update the document with the modified order array
//           await updateDoc(orderDocRef, {
//             orders: [
//               ...orderArray.slice(0, orderIndex), // Orders before the updated one
//               updatedOrder, // The updated order
//               ...orderArray.slice(orderIndex + 1), // Orders after the updated one
//             ],
//           });
  
//           Alert.alert('Success', 'Order has been denied.');
//           fetchOrders(); // Re-fetch the orders after denying
//         }
//       });
//     } catch (error) {
//       console.error('Error denying order:', error);
//       Alert.alert('Error', 'Failed to deny the order.');
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Fetch orders when component mounts or farmerId is updated
//   useEffect(() => {
//     fetchFarmerIdFromStorage(); // Fetch farmerId when the component mounts
//   }, []);

//   useEffect(() => {
//     if (farmerId) {
//       fetchOrders(); // Fetch orders once farmerId is available
//     }
//   }, [farmerId]);

//   // Render individual order items
//   const renderItem = ({ item }) => (
//     <View style={{ marginBottom: 10, padding: 15, borderWidth: 1 }}>
//       <Text>Order ID: {item.orderId}</Text>
//       <Text>Crop: {item.cropName}</Text>
//       <Text>Status: {item.farmerStatus || 'Pending'}</Text>
//       <Text>Quantity: {item.quantity}</Text>
//       <Text>Total Price: ₹{item.totalPrice}</Text>
//       <Text>Address: {item.address}</Text>
//       <View style={{ marginTop: 10 }}>
//         <Button title="Accept" onPress={() => acceptOrder(item.orderId)} />
//         <Button title="Deny" onPress={() => denyOrder(item.orderId)} color="red" />
//       </View>
//     </View>
//   );

//   console.log('Orders:', orders); // Debug log to check orders data

//   return (
//     <View style={{ flex: 1, padding: 20 }}>
//       {loading ? (
//         <ActivityIndicator size="large" color="#0000ff" />
//       ) : (
//         <FlatList
//           data={orders}
//           keyExtractor={(item) => item.orderId} // Use orderId as the unique key for each order
//           renderItem={renderItem}
//           ListEmptyComponent={<Text>No orders found for this farmer.</Text>} // Empty state if no orders
//         />
//       )}
//     </View>
//   );
// };

// export default OrderManagementScreen;
// import React, { useState, useEffect } from 'react';
// import { View, Text, Button, Alert, FlatList, ActivityIndicator } from 'react-native';
// import { Picker } from '@react-native-picker/picker'; // Updated import
// import AsyncStorage from '@react-native-async-storage/async-storage';
// import { collection, getDocs, query, where, doc, updateDoc, Timestamp } from 'firebase/firestore';
// import { db } from '../../firebaseConfig';

// const OrderManagementScreen = () => {
//   const [orders, setOrders] = useState([]); // State to hold orders
//   const [loading, setLoading] = useState(true); // Loading state for fetching data
//   const [farmerId, setFarmerId] = useState(null); // State to hold farmerId
//   const [statusFilter, setStatusFilter] = useState(''); // State for status filter
//   const [dateFilter, setDateFilter] = useState(''); // State for date filter

//   const fetchFarmerIdFromStorage = async () => {
//     try {
//       const storedFarmerId = await AsyncStorage.getItem('aadharNumber');
//       if (storedFarmerId !== null) {
//         setFarmerId(storedFarmerId);
//         console.log('Farmer ID retrieved:', storedFarmerId);
//       } else {
//         Alert.alert('Error', 'Farmer ID not found in storage.');
//       }
//     } catch (error) {
//       console.error('Error fetching farmerId from AsyncStorage:', error);
//       Alert.alert('Error', 'Failed to fetch farmer ID.');
//     }
//   };

//   const fetchOrders = async () => {
//     if (!farmerId) return;

//     try {
//       const ordersRef = collection(db, 'orders');
//       let orderQuery = query(ordersRef);

//       if (statusFilter) {
//         orderQuery = query(orderQuery, where('farmerStatus', '==', statusFilter));
//       }
//       if (dateFilter) {
//         const date = new Date(dateFilter);
//         const startOfDay = new Date(date.setHours(0, 0, 0, 0));
//         const endOfDay = new Date(date.setHours(23, 59, 59, 999));
//         orderQuery = query(orderQuery, where('createdAt', '>=', Timestamp.fromDate(startOfDay)), where('createdAt', '<=', Timestamp.fromDate(endOfDay)));
//       }

//       const querySnapshot = await getDocs(orderQuery);

//       const ordersData = [];
//       querySnapshot.forEach((docSnapshot) => {
//         const orderArray = docSnapshot.data().orders || [];
//         orderArray.forEach((order) => {
//           if (order.farmerId === farmerId) {
//             ordersData.push({ ...order, buyerEmail: docSnapshot.id });
//           }
//         });
//       });

//       setOrders(ordersData);
//     } catch (error) {
//       console.error('Error fetching orders:', error);
//       Alert.alert('Error', 'Failed to fetch orders.');
//     } finally {
//       setLoading(false);
//     }
//   };

//   const acceptOrder = async (orderId) => {
//     try {
//       setLoading(true);
//       const ordersRef = collection(db, 'orders');
//       const querySnapshot = await getDocs(ordersRef);

//       querySnapshot.forEach(async (docSnapshot) => {
//         const orderArray = docSnapshot.data().orders || [];
//         const orderIndex = orderArray.findIndex(order => order.orderId === orderId);

//         if (orderIndex !== -1) {
//           const orderDocRef = doc(db, 'orders', docSnapshot.id);
//           const updatedOrder = orderArray[orderIndex];

//           updatedOrder.farmerStatus = 'Accepted';

//           await updateDoc(orderDocRef, {
//             orders: [
//               ...orderArray.slice(0, orderIndex),
//               updatedOrder,
//               ...orderArray.slice(orderIndex + 1),
//             ],
//           });

//           Alert.alert('Success', 'Order has been accepted.');
//           fetchOrders();
//         }
//       });
//     } catch (error) {
//       console.error('Error accepting order:', error);
//       Alert.alert('Error', 'Failed to accept the order.');
//     } finally {
//       setLoading(false);
//     }
//   };

//   const denyOrder = async (orderId) => {
//     try {
//       setLoading(true);
//       const ordersRef = collection(db, 'orders');
//       const querySnapshot = await getDocs(ordersRef);

//       querySnapshot.forEach(async (docSnapshot) => {
//         const orderArray = docSnapshot.data().orders || [];
//         const orderIndex = orderArray.findIndex(order => order.orderId === orderId);

//         if (orderIndex !== -1) {
//           const orderDocRef = doc(db, 'orders', docSnapshot.id);
//           const updatedOrder = orderArray[orderIndex];

//           updatedOrder.farmerStatus = 'Denied';

//           await updateDoc(orderDocRef, {
//             orders: [
//               ...orderArray.slice(0, orderIndex),
//               updatedOrder,
//               ...orderArray.slice(orderIndex + 1),
//             ],
//           });

//           Alert.alert('Success', 'Order has been denied.');
//           fetchOrders();
//         }
//       });
//     } catch (error) {
//       console.error('Error denying order:', error);
//       Alert.alert('Error', 'Failed to deny the order.');
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchFarmerIdFromStorage();
//   }, []);

//   useEffect(() => {
//     if (farmerId) {
//       fetchOrders();
//     }
//   }, [farmerId, statusFilter, dateFilter]);

//   const renderItem = ({ item }) => (
//     <View style={{ marginBottom: 10, padding: 15, borderWidth: 1 }}>
//       <Text>Order ID: {item.orderId}</Text>
//       <Text>Crop: {item.cropName}</Text>
//       <Text>Status: {item.farmerStatus || 'Pending'}</Text>
//       <Text>Quantity: {item.quantity}</Text>
//       <Text>Total Price: ₹{item.totalPrice}</Text>
//       <Text>Address: {item.address}</Text>
//       <View style={{ marginTop: 10 }}>
//         <Button title="Accept" onPress={() => acceptOrder(item.orderId)} />
//         <Button title="Deny" onPress={() => denyOrder(item.orderId)} color="red" />
//       </View>
//     </View>
//   );

//   return (
//     <View style={{ flex: 1, padding: 20 }}>
//       <Text>Status Filter</Text>
//       <Picker selectedValue={statusFilter} onValueChange={setStatusFilter}>
//         <Picker.Item label="All" value="" />
//         <Picker.Item label="Accepted" value="Accepted" />
//         <Picker.Item label="Pending" value="Pending" />
//         <Picker.Item label="Denied" value="Denied" />
//       </Picker>

//       <Text>Date Filter</Text>
//       <Picker selectedValue={dateFilter} onValueChange={setDateFilter}>
//         <Picker.Item label="All" value="" />
//         <Picker.Item label="Today" value={new Date().toISOString().split('T')[0]} />
//       </Picker>

//       {loading ? (
//         <ActivityIndicator size="large" color="#0000ff" />
//       ) : (
//         <FlatList
//           data={orders}
//           keyExtractor={(item) => item.orderId}
//           renderItem={renderItem}
//           ListEmptyComponent={<Text>No orders found for this farmer.</Text>}
//         />
//       )}
//     </View>
//   );
// };

// export default OrderManagementScreen;


import React, { useState, useEffect } from 'react';
import { View, Text, Button, Alert, FlatList, ActivityIndicator, TouchableOpacity } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { collection, getDocs, query, where, Timestamp } from 'firebase/firestore';
import { db } from '../../firebaseConfig';
import { debounce } from 'lodash'; // Import debounce from lodash

const OrderManagementScreen = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [farmerId, setFarmerId] = useState(null);
  const [statusFilter, setStatusFilter] = useState(''); // Single status filter
  const [dateFilter, setDateFilter] = useState(''); // Single date filter
  const [filters, setFilters] = useState({ status: '', date: '' });

  const fetchFarmerIdFromStorage = async () => {
    try {
      const storedFarmerId = await AsyncStorage.getItem('aadharNumber');
      if (storedFarmerId) {
        setFarmerId(storedFarmerId);
        console.log('Farmer ID retrieved:', storedFarmerId);
      } else {
        Alert.alert('Error', 'Farmer ID not found in storage.');
      }
    } catch (error) {
      console.error('Error fetching farmerId from AsyncStorage:', error);
      Alert.alert('Error', 'Failed to fetch farmer ID.');
    }
  };

  const fetchOrders = async () => {
    if (!farmerId) return;

    setLoading(true);

    try {
      const ordersRef = collection(db, 'orders');
      let orderQuery = query(ordersRef);

      // Applying status filter
      if (filters.status) {
        orderQuery = query(orderQuery, where('farmerStatus', '==', filters.status));
      }

      // Applying date filter
      if (filters.date) {
        const date = new Date(filters.date);
        const startOfDay = new Date(date.setHours(0, 0, 0, 0));
        const endOfDay = new Date(date.setHours(23, 59, 59, 999));
        orderQuery = query(orderQuery, where('createdAt', '>=', Timestamp.fromDate(startOfDay)), where('createdAt', '<=', Timestamp.fromDate(endOfDay)));
      }

      const querySnapshot = await getDocs(orderQuery);
      const ordersData = [];

      querySnapshot.forEach((docSnapshot) => {
        const orderArray = docSnapshot.data().orders || [];
        orderArray.forEach((order) => {
          if (order.farmerId === farmerId) {
            ordersData.push({ ...order, buyerEmail: docSnapshot.id });
          }
        });
      });

      setOrders(ordersData);
    } catch (error) {
      console.error('Error fetching orders:', error);
      Alert.alert('Error', 'Failed to fetch orders.');
    } finally {
      setLoading(false);
    }
  };

  // Debounced function to fetch orders
  const debouncedFetchOrders = debounce(fetchOrders, 500);

  useEffect(() => {
    fetchFarmerIdFromStorage();
  }, []);

  useEffect(() => {
    if (farmerId) {
      debouncedFetchOrders();
    }
  }, [filters, farmerId]);

  const renderItem = ({ item }) => (
    <View style={{ marginBottom: 10, padding: 15, borderWidth: 1 }}>
      <Text>Order ID: {item.orderId}</Text>
      <Text>Crop: {item.cropName}</Text>
      <Text>Status: {item.farmerStatus || 'Pending'}</Text>
      <Text>Quantity: {item.quantity}</Text>
      <Text>Total Price: ₹{item.totalPrice}</Text>
      <Text>Address: {item.address}</Text>
      <View style={{ marginTop: 10 }}>
        <Button title="Accept" onPress={() => acceptOrder(item.orderId)} />
        <Button title="Deny" onPress={() => denyOrder(item.orderId)} color="red" />
      </View>
    </View>
  );

  return (
    <View style={{ flex: 1, padding: 20 }}>
      <Text>Status Filter</Text>
      <Picker
        selectedValue={filters.status}
        onValueChange={(value) => setFilters({ ...filters, status: value })}
      >
        <Picker.Item label="All" value="" />
        <Picker.Item label="Accepted" value="Accepted" />
        <Picker.Item label="Pending" value="Pending" />
        <Picker.Item label="Denied" value="Denied" />
      </Picker>

      <Text>Date Filter</Text>
      <Picker
        selectedValue={filters.date}
        onValueChange={(value) => setFilters({ ...filters, date: value })}
      >
        <Picker.Item label="All" value="" />
        <Picker.Item label="Today" value={new Date().toISOString().split('T')[0]} />
        {/* Add more date filters like 'This Week', 'This Month' here */}
      </Picker>

      {loading ? (
        <ActivityIndicator size="large" color="#0000ff" />
      ) : (
        <FlatList
          data={orders}
          keyExtractor={(item) => item.orderId}
          renderItem={renderItem}
          ListEmptyComponent={<Text>No orders found for this farmer.</Text>}
        />
      )}
    </View>
  );
};

export default OrderManagementScreen;
