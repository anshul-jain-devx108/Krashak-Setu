// import React, { useState, useEffect } from 'react';
// import {
//   View,
//   Text,
//   StyleSheet,
//   TextInput,
//   TouchableOpacity,
//   ScrollView,
//   Alert,
//   Dimensions,
//   Platform,
//   StatusBar,
// } from 'react-native';

// import * as ImagePicker from 'expo-image-picker';
// import * as FirebaseStorage from 'firebase/storage';
// import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
// import { getFirestore, collection, addDoc } from 'firebase/firestore';
// import { AsyncStorage } from 'react-native'; // For storing Aadhar

// const { width } = Dimensions.get('window');

// export default function ProductListingScreen() {
//   const [product, setProduct] = useState({
//     aadhar: '', // Aadhar will be fetched automatically from AsyncStorage
//     name: '',
//     actualPrice: '',
//     negotiablePrice: '',
//     description: '',
//     harvestDate: '',
//     listingDateTime: '',
//     availableStock: '',
//     imageUri: '', // For image URL
//   });
//   const [image, setImage] = useState(null); // State to hold the image

//   // Fetch Aadhar from AsyncStorage when component mounts
//   useEffect(() => {
//     const fetchAadhar = async () => {
//       try {
//         const storedAadhar = await AsyncStorage.getItem('aadhar');
//         if (storedAadhar) {
//           setProduct((prevProduct) => ({
//             ...prevProduct,
//             aadhar: storedAadhar,
//           }));
//         }
//       } catch (error) {
//         console.error('Error fetching Aadhar:', error);
//       }
//     };

//     fetchAadhar();
//   }, []);

//   const handleInputChange = (field, value) => {
//     setProduct({ ...product, [field]: value });
//   };

//   const handleImagePicker = async () => {
//     let result = await ImagePicker.launchImageLibraryAsync({
//       mediaTypes: ImagePicker.MediaTypeOptions.Images,
//       allowsEditing: true,
//       aspect: [4, 3],
//       quality: 1,
//     });

//     if (!result.canceled) {
//       setImage(result.assets[0].uri); // Set the selected image URI
//     }
//   };

//   const handleSubmit = async () => {
//     if (
//       product.name &&
//       product.actualPrice &&
//       product.availableStock &&
//       image
//     ) {
//       try {
//         // Upload image to Firebase Storage
//         const storage = getStorage();
//         const response = await fetch(image);
//         const blob = await response.blob();
//         const imageRef = ref(storage, 'productImages/' + Date.now());
//         await uploadBytes(imageRef, blob);

//         // Get image URL
//         const imageUrl = await getDownloadURL(imageRef);

//         // Add product to Firestore
//         const db = getFirestore();
//         await addDoc(collection(db, 'products'), {
//           ...product,
//           imageUrl,
//           createdAt: new Date(),
//         });

//         Alert.alert('Success', 'Product listed successfully!');
//         setProduct({
//           aadhar: '',
//           name: '',
//           actualPrice: '',
//           negotiablePrice: '',
//           description: '',
//           harvestDate: '',
//           listingDateTime: '',
//           availableStock: '',
//           imageUri: '',
//         });
//         setImage(null); // Clear the image after upload
//       } catch (error) {
//         Alert.alert('Error', 'Failed to list product. Please try again.');
//         console.error('Error uploading product:', error);
//       }
//     } else {
//       Alert.alert('Error', 'Please fill in all required fields!');
//     }
//   };

//   return (
//     <ScrollView
//       style={styles.container}
//       contentContainerStyle={styles.contentContainer}
//     >
//       {/* Header */}
//       <View style={styles.header}>
//         <Text style={styles.headerText}>🌾 Product Listing 🌾</Text>
//         <Text style={styles.subHeaderText}>Empowering Farmers</Text>
//       </View>

//       {/* Form */}
//       <View style={styles.form}>
//         {/* Product Name */}
//         <Text style={styles.label}>Product Name</Text>
//         <TextInput
//           style={styles.input}
//           placeholder="Enter Product Name"
//           value={product.name}
//           onChangeText={(value) => handleInputChange('name', value)}
//         />

//         {/* Actual Price */}
//         <Text style={styles.label}>Actual Price (₹)</Text>
//         <TextInput
//           style={styles.input}
//           placeholder="Enter Actual Price"
//           keyboardType="numeric"
//           value={product.actualPrice}
//           onChangeText={(value) => handleInputChange('actualPrice', value)}
//         />

//         {/* Negotiable Price */}
//         <Text style={styles.label}>Negotiable Price (₹)</Text>
//         <TextInput
//           style={styles.input}
//           placeholder="Enter Negotiable Price"
//           keyboardType="numeric"
//           value={product.negotiablePrice}
//           onChangeText={(value) => handleInputChange('negotiablePrice', value)}
//         />

//         {/* Description */}
//         <Text style={styles.label}>Description</Text>
//         <TextInput
//           style={[styles.input, styles.textArea]}
//           placeholder="Enter Product Description"
//           multiline
//           numberOfLines={4}
//           value={product.description}
//           onChangeText={(value) => handleInputChange('description', value)}
//         />

//         {/* Harvest Date */}
//         <Text style={styles.label}>Harvest Date</Text>
//         <TextInput
//           style={styles.input}
//           placeholder="Enter Harvest Date (YYYY-MM-DD)"
//           value={product.harvestDate}
//           onChangeText={(value) => handleInputChange('harvestDate', value)}
//         />

//         {/* Listing Date & Time */}
//         <Text style={styles.label}>Listing Date & Time</Text>
//         <TextInput
//           style={styles.input}
//           placeholder="Enter Listing Date & Time"
//           value={product.listingDateTime}
//           onChangeText={(value) => handleInputChange('listingDateTime', value)}
//         />

//         {/* Available Stock */}
//         <Text style={styles.label}>Available Stock (kg)</Text>
//         <TextInput
//           style={styles.input}
//           placeholder="Enter Available Stock"
//           keyboardType="numeric"
//           value={product.availableStock}
//           onChangeText={(value) => handleInputChange('availableStock', value)}
//         />

//         {/* Image Upload Button */}
//         <TouchableOpacity style={styles.button} onPress={handleImagePicker}>
//           <Text style={styles.buttonText}>Upload Product Image</Text>
//         </TouchableOpacity>

//         {image && (
//           <View style={styles.imageContainer}>
//             <Text style={styles.label}>Selected Image</Text>
//             <Image source={{ uri: image }} style={styles.imagePreview} />
//           </View>
//         )}

//         {/* Submit Button */}
//         <TouchableOpacity style={styles.button} onPress={handleSubmit}>
//           <Text style={styles.buttonText}>Submit</Text>
//         </TouchableOpacity>
//       </View>
//     </ScrollView>
//   );
// }

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#f3f8ec',
//   },
//   contentContainer: {
//     paddingBottom: 30,
//   },
//   header: {
//     backgroundColor: '#388e3c',
//     paddingVertical: 20,
//     alignItems: 'center',
//     justifyContent: 'center',
//     borderBottomLeftRadius: 20,
//     borderBottomRightRadius: 20,
//     paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight + 10 : 20,
//   },
//   headerText: {
//     fontSize: 26,
//     fontWeight: 'bold',
//     color: '#fff',
//     textAlign: 'center',
//   },
//   subHeaderText: {
//     fontSize: 16,
//     color: '#f9fbe7',
//     marginTop: 5,
//     fontStyle: 'italic',
//   },
//   form: {
//     padding: 20,
//   },
//   label: {
//     fontSize: 16,
//     color: '#2e7d32',
//     marginBottom: 5,
//     fontWeight: 'bold',
//   },
//   input: {
//     backgroundColor: '#fff',
//     borderRadius: 8,
//     padding: 10,
//     fontSize: 16,
//     color: '#000',
//     marginBottom: 15,
//     borderWidth: 1,
//     borderColor: '#ccc',
//   },
//   textArea: {
//     height: 80,
//     textAlignVertical: 'top',
//   },
//   button: {
//     backgroundColor: '#4caf50',
//     paddingVertical: 15,
//     alignItems: 'center',
//     borderRadius: 8,
//     marginTop: 20,
//   },
//   buttonText: {
//     color: '#fff',
//     fontSize: 18,
//     fontWeight: 'bold',
//   },
//   imageContainer: {
//     marginTop: 15,
//     alignItems: 'center',
//   },
//   imagePreview: {
//     width: 100,
//     height: 100,
//     resizeMode: 'contain',
//     marginTop: 10,
//   },
// });

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  Dimensions,
  Platform,
  StatusBar,
  Image,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import * as FirebaseStorage from 'firebase/storage';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { getFirestore, collection, addDoc } from 'firebase/firestore';
import AsyncStorage from '@react-native-async-storage/async-storage'; // For storing Aadhar
import DateTimePicker from '@react-native-community/datetimepicker'; // Importing DateTimePicker
import { Picker } from '@react-native-picker/picker'; // For dropdown
import { db, storage } from '../../firebaseConfig';

const { width } = Dimensions.get('window');

export default function ProductListingScreen() {
  const [product, setProduct] = useState({
    aadhar: '', // Aadhar will be fetched automatically from AsyncStorage
    name: '',
    category: '', // New field for category
    actualPrice: '',
    negotiablePrice: '',
    description: '',
    harvestDate: new Date(), // Initial empty string for harvest date
    listingDateTime: '', // Automatically set listing date and time
    availableStock: '',
    imageUri: '', // For image URL
  });
  const [image, setImage] = useState(null); // State to hold the image
  const [showDatePicker, setShowDatePicker] = useState(false); // To control the date picker visibility

  // Fetch Aadhar and set listing date & time automatically when component mounts
  useEffect(() => {
    const fetchAadhar = async () => {
      try {
        const storedAadhar = await AsyncStorage.getItem('aadhar');
        if (storedAadhar) {
          setProduct((prevProduct) => ({
            ...prevProduct,
            aadhar: storedAadhar,
          }));
        }

        // Set listing date & time automatically
        setProduct((prevProduct) => ({
          ...prevProduct,
          listingDateTime: new Date().toLocaleString(),
        }));
      } catch (error) {
        console.error('Error fetching Aadhar:', error);
      }
    };

    fetchAadhar();
  }, []);

  const handleInputChange = (field, value) => {
    setProduct({ ...product, [field]: value });
  };

  const handleImagePicker = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.canceled) {
      setImage(result.assets[0].uri); // Set the selected image URI
    }
  };

  const handleDateChange = (event, selectedDate) => {
    const currentDate = selectedDate || product.harvestDate;
    setShowDatePicker(Platform.OS === 'ios' ? true : false);
    setProduct((prevProduct) => ({
      ...prevProduct,
      harvestDate: currentDate,
    }));
  };

  const handleSubmit = async () => {
    if (product.name && product.actualPrice && product.availableStock && product.category && image) {
      try {
        // Upload image to Firebase Storage
        
        const imageRef = ref(storage, 'productImages/' + Date.now());
        const response = await fetch(image);
        const blob = await response.blob();
        await uploadBytes(imageRef, blob);

        // Get image URL
        const imageUrl = await getDownloadURL(imageRef);

         // Add product to Firestore
      const storedAadhar = await AsyncStorage.getItem('aadharNumber'); // Fetch the Aadhar value from AsyncStorage
      if (!storedAadhar) {
        Alert.alert('Error', 'Aadhar number is missing!');
        return;
      }

        // Add product to Firestore
        
        await addDoc(collection(db, 'crops'), {
          ...product,
          imageUrl,
          aadhar: storedAadhar,
          createdAt: new Date(),
        });

        Alert.alert('Success', 'Product listed successfully!');
        setProduct({
          aadhar: '',
          name: '',
          category: '',
          actualPrice: '',
          negotiablePrice: '',
          description: '',
          harvestDate: new Date(),
          listingDateTime: '',
          availableStock: '',
          imageUri: '',
        });
        setImage(null); // Clear the image after upload
      } catch (error) {
        Alert.alert('Error', 'Failed to list product. Please try again.');
        console.error('Error uploading product:', error);
      }
    } else {
      Alert.alert('Error', 'Please fill in all required fields!');
    }
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.contentContainer}
    >
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerText}>🌾 Product Listing 🌾</Text>
        <Text style={styles.subHeaderText}>Empowering Farmers</Text>
      </View>

      {/* Form */}
      <View style={styles.form}>
        {/* Product Name */}
        <Text style={styles.label}>Product Name</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter Product Name"
          value={product.name}
          onChangeText={(value) => handleInputChange('name', value)}
        />

        {/* Product Category */}
        <Text style={styles.label}>Category</Text>
        <View style={styles.dropdown}>
          <Picker
            selectedValue={product.category}
            onValueChange={(value) => handleInputChange('category', value)}
          >
            <Picker.Item label="Select Category" value="" />
            <Picker.Item label="Fruits" value="Fruits" />
            <Picker.Item label="Vegetables" value="Vegetables" />
            <Picker.Item label="Grains" value="Grains" />
            <Picker.Item label="Dairy Products" value="Dairy Products" />
          </Picker>
        </View>

        {/* Actual Price */}
        <Text style={styles.label}>Actual Price (₹)</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter Actual Price"
          keyboardType="numeric"
          value={product.actualPrice}
          onChangeText={(value) => handleInputChange('actualPrice', value)}
        />

        {/* Negotiable Price */}
        <Text style={styles.label}>Negotiable Price (₹)</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter Negotiable Price"
          keyboardType="numeric"
          value={product.negotiablePrice}
          onChangeText={(value) => handleInputChange('negotiablePrice', value)}
        />

        {/* Description */}
        <Text style={styles.label}>Description</Text>
        <TextInput
          style={[styles.input, styles.textArea]}
          placeholder="Enter Product Description"
          multiline
          numberOfLines={4}
          value={product.description}
          onChangeText={(value) => handleInputChange('description', value)}
        />

        {/* Harvest Date */}
        <Text style={styles.label}>Harvest Date</Text>
        <TouchableOpacity
          style={styles.input}
          onPress={() => setShowDatePicker(true)}
        >
          <Text style={styles.dateText}>
            {product.harvestDate.toLocaleDateString() || 'Select Harvest Date'}
          </Text>
        </TouchableOpacity>

        {/* DateTimePicker Modal */}
        {showDatePicker && (
          <DateTimePicker
            testID="dateTimePicker"
            value={product.harvestDate}
            mode="date"
            display="default"
            onChange={handleDateChange}
          />
        )}

        {/* Available Stock */}
        <Text style={styles.label}>Available Stock (kg)</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter Available Stock"
          keyboardType="numeric"
          value={product.availableStock}
          onChangeText={(value) => handleInputChange('availableStock', value)}
        />

        {/* Image Upload Button */}
        <TouchableOpacity style={styles.button} onPress={handleImagePicker}>
          <Text style={styles.buttonText}>Upload Product Image</Text>
        </TouchableOpacity>

        {image && (
          <View style={styles.imageContainer}>
            <Text style={styles.label}>Selected Image</Text>
            <Image source={{ uri: image }} style={styles.imagePreview} />
          </View>
        )}

        {/* Submit Button */}
        <TouchableOpacity style={styles.button} onPress={handleSubmit}>
          <Text style={styles.buttonText}>Submit</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f3f8ec',
  },
  contentContainer: {
    paddingBottom: 30,
  },
  header: {
    backgroundColor: '#388e3c',
    paddingVertical: 20,
    alignItems: 'center',
    justifyContent: 'center',
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20,
    paddingTop: Platform.OS === 'android' ? StatusBar.currentHeight + 10 : 20,
  },
  headerText: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
  },
  subHeaderText: {
    fontSize: 16,
    color: '#fff',
  },
  form: {
    paddingHorizontal: 20,
    marginTop: 20,
  },
  label: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  input: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    padding: 10,
    marginBottom: 15,
    fontSize: 16,
  },
  textArea: {
    height: 100,
  },
  dropdown: {
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 8,
    marginBottom: 15,
  },
  button: {
    backgroundColor: '#388e3c',
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 15,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  imageContainer: {
    alignItems: 'center',
    marginBottom: 15,
  },
  imagePreview: {
    width: 150,
    height: 150,
    borderRadius: 8,
    marginTop: 10,
  },
  dateText: {
    fontSize: 16,
    color: '#333',
  },
});
