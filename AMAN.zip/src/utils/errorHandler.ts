export const handleAsyncError = (error: any, message: string) => {
    console.error(`${message}:`, error);
    // Optionally show an error toast/snackbar
  };
  